# memtoc

<!-- badges: start -->
<!-- badges: end -->

Tictoc-style memory tracking for R. Simple start/stop syntax for monitoring RAM usage during code execution, with continuous background polling to capture true peak memory across main process and parallel workers.

Inspired by the [tictoc](https://github.com/jabiru/tictoc) package.

## Installation

You can install the development version of memtoc from GitHub:
```r
# install.packages("pak")
pak::pak("yourusername/memtoc")
```

Or install from a local directory:
```r
# install.packages("devtools")
devtools::install_local("path/to/memtoc")
```

## Quick Start

```r
library(memtoc)

# Basic usage with background polling (captures true peak memory)
tic_mem("data processing")
data <- read.csv("large_file.csv")
processed <- transform(data)
toc_mem()
#> ✔ data processing: 142.3 MB peak | 89.1 MB current | 2.34 sec | 3 samples
```

## Features

### Background Polling

By default, `memtoc` spawns a background process that continuously samples memory usage:

```r
tic_mem("heavy computation", interval = 0.5)  # Poll every 0.5 seconds
x <- matrix(rnorm(1e8), ncol = 1000)          # ~800 MB allocation
result <- toc_mem()
#> ✔ heavy computation: 812.4 MB peak | 801.2 MB current | 3.21 sec | 7 samples

# Access the full memory trajectory
result$trajectory
#>             timestamp   pid       rss
#> 1 2024-12-10 14:23:01 12345 104857600
#> 2 2024-12-10 14:23:01 12345 524288000
#> 3 2024-12-10 14:23:02 12345 812400000
#> ...
```

For quick operations, use snapshot mode to skip the background process:

```r
tic_mem("quick op", interval = NULL)  # Snapshot only, no background process
y <- 1:100
toc_mem()
```

### Parallel Worker Monitoring (New in v0.3.0)

Track memory across `future` workers automatically:

```r
library(future)
library(future.apply)

# Set up parallel workers
plan(multisession, workers = 4)

# Check detected workers
mem_parallel_info()
#> ── Parallel Backend Info
#> • Main process PID: 12345
#> • Current plan: multisession
#> • Workers configured: 4
#> • Detected worker PIDs: 12346, 12347, 12348, 12349

# Monitor all workers during parallel computation
tic_mem("parallel job", workers = "auto")
result <- future_lapply(1:100, function(i) {
  x <- rnorm(1e6)  # Each worker allocates ~8 MB
  mean(x)
})
toc_mem()
#> ✔ parallel job: 1.2 GB peak | 245.3 MB current | 5.4 sec | 12 samples | 4 workers

# View per-worker statistics
result$worker_stats
#>     pid is_main   mem_peak   mem_mean n_samples
#> 1 12345    TRUE  245366784  198456320         12
#> 2 12346   FALSE  312475648  289543168         12
#> 3 12347   FALSE  298234880  276543488         12
#> 4 12348   FALSE  305678336  283456512         12
#> 5 12349   FALSE  289543168  267890432         12

# Reset plan
plan(sequential)
```

Worker monitoring options:
- `workers = "auto"`: Auto-detect future workers and child processes (default)
- `workers = "none"`: Only monitor main process
- `workers = "children"`: Monitor main + all child processes
- `workers = c(pid1, pid2)`: Explicit PID list

### Nested Tracking

Track memory for an entire pipeline while also tracking individual steps:

```r
tic_mem("full pipeline")

  tic_mem("load data")
  data <- read.csv("data.csv")
  toc_mem()
  #> ✔ load data: 50.2 MB peak | 50.2 MB current | 1.2 sec | 2 samples

  tic_mem("feature engineering")
  features <- create_features(data)
  toc_mem()
  #> ✔ feature engineering: 125.8 MB peak | 98.3 MB current | 5.4 sec | 6 samples

  tic_mem("model training")
  model <- train_model(features)
  toc_mem()
  #> ✔ model training: 512.1 MB peak | 201.5 MB current | 45.2 sec | 46 samples

toc_mem()
#> ✔ full pipeline: 512.1 MB peak | 201.5 MB current | 51.8 sec | 52 samples
```

### System Memory Warnings

Get alerts when system RAM is running low:

```r
tic_mem("memory hog")
# ... allocate lots of memory ...
toc_mem()
#> ✔ memory hog: 12.4 GB peak | 11.2 GB current | 45.2 sec | 45 samples
#> ⚠ System RAM high: 87.3% used
```

### Logging

Collect results for later analysis:

```r
mem_clearlog()

for (i in 1:10) {
  tic_mem(paste("iteration", i))
  # ... do work ...
  toc_mem(log = TRUE, quiet = TRUE)
}

# Get all results as a data frame
results <- mem_log()
mean(results$mem_peak)
max(results$elapsed)
```

### Crash Recovery

If R crashes during a long computation, recover the data:

```r
# After restarting R, check for recovery files
mem_recover()
#> ℹ Found 1 recovery file:
#>   • PID 12345: 15.2 KB, 152 samples, modified 2024-12-10 14:30:00

# Recover the data
recovered <- mem_recover(pid = 12345)
```

### Diagnostics

Troubleshoot issues with background monitoring:

```r
# Quick capability check
mem_capabilities()
#>     memory_queries background_polling 
#>               TRUE               TRUE

# Detailed diagnostics
mem_diagnose()

# Check parallel setup
mem_parallel_info()
```

## API Reference

| Function | Description |
|----------|-------------|
| `tic_mem(msg, interval, persist, workers)` | Start tracking. `workers` controls parallel monitoring. |
| `toc_mem(log, quiet)` | Stop tracking and report. Use `log = TRUE` to save results. |
| `mem_log()` | Get logged results as a data frame. |
| `mem_clearlog()` | Clear the log. |
| `mem_clear()` | Clear the tracking stack and stop monitors. |
| `mem_recover(pid, path)` | Recover data from a crashed session. |
| `mem_capabilities()` | Check which features are available. |
| `mem_diagnose()` | Run detailed diagnostics. |
| `mem_parallel_info()` | Check parallel backend status. |
| `mem_print_log()` | Print the log in human-readable format. |

## Roadmap

- [x] **MVP 1**: Basic tic_mem/toc_mem with nesting and logging
- [x] **MVP 2**: Continuous background polling for true peak detection
- [x] **MVP 3**: Parallel worker monitoring (future package integration)
- [ ] **MVP 4**: CRAN release

## License

MIT
